# Atributes
Nombre=""
Apellido1=""
Apellido2=""
dni=""
telefono=0
# Definitions/Methods
for i in range(5):
    print("Introduce tu nombre:")
    Nombre=input()
    print(f"Introduce tu primer apellido:")
    Apellido1 = input()
    print(f"Introduce tu segundo apellido:")
    Apellido2 = input()
    print(f"Introduce tu dni:")
    dni = input()
    print(f"Introduce tu telefono:")
    telefono = input()